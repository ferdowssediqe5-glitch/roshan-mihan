
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

const red = Color(0xFFE50914);
const black = Color(0xFF111111);
const bg = Color(0xFFF8F8F8);

void main() => runApp(const RoshanMihanApp());

class RoshanMihanApp extends StatelessWidget {
  const RoshanMihanApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'روشن میهن',
    theme: ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: bg,
      colorScheme: ColorScheme.fromSeed(seedColor: red),
      fontFamily: 'Arial',
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: red, width: 1.2)),
      ),
    ),
    home: const MainShell(),
  );
}

class Product {
  final String name, category, specs;
  const Product({required this.name, required this.category, required this.specs});
}

const products = <Product>[
  Product(name: 'ماربل شیت', category: 'ماربل شیت', specs: 'عرض ۱.۲۰ متر • ارتفاع ۲.۸۰ متر • ضخامت ۲.۵ میلی‌متر\nضد نم و آب • سبک • قابل شستشو • نصب سریع'),
  Product(name: 'فومیزه PVC — ۸ میلی‌متر', category: 'فومیزه PVC', specs: 'ضخامت ۸ میلی‌متر • مناسب محیط‌های مرطوب'),
  Product(name: 'فومیزه PVC — ۱۰ میلی‌متر', category: 'فومیزه PVC', specs: 'ضخامت ۱۰ میلی‌متر • مناسب محیط‌های مرطوب'),
  Product(name: 'فومیزه PVC — ۱۶ میلی‌متر', category: 'فومیزه PVC', specs: 'ضخامت ۱۶ میلی‌متر • مناسب محیط‌های مرطوب'),
];

Future<void> openWhatsApp({String message = ''}) async {
  final uri = Uri.parse('https://wa.me/93711640794?text=${Uri.encodeComponent(message)}');
  await launchUrl(uri, mode: LaunchMode.externalApplication);
}
Future<void> makeCall() async => launchUrl(Uri.parse('tel:+93711853612'));
Future<void> openStoreMap() async => launchUrl(Uri.parse('https://maps.app.goo.gl/xwjXziqMeeASpk7t5'), mode: LaunchMode.externalApplication);

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override State<MainShell> createState() => _MainShellState();
}
class _MainShellState extends State<MainShell> {
  int index = 0;
  final favorites = <String>{};
  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(onNavigate: (i) => setState(() => index = i)),
      ProductsPage(favorites: favorites, onFav: (p) => setState(() => favorites.contains(p.name) ? favorites.remove(p.name) : favorites.add(p.name))),
      const GalleryPage(), const CalculatorPage(), const MorePage(),
    ];
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: SafeArea(child: pages[index]),
        bottomNavigationBar: NavigationBar(
          selectedIndex: index, onDestinationSelected: (i) => setState(() => index = i),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'خانه'),
            NavigationDestination(icon: Icon(Icons.shopping_bag_outlined), selectedIcon: Icon(Icons.shopping_bag), label: 'محصولات'),
            NavigationDestination(icon: Icon(Icons.photo_library_outlined), selectedIcon: Icon(Icons.photo_library), label: 'گالری'),
            NavigationDestination(icon: Icon(Icons.calculate_outlined), selectedIcon: Icon(Icons.calculate), label: 'متراژ'),
            NavigationDestination(icon: Icon(Icons.more_horiz), selectedIcon: Icon(Icons.more_horiz), label: 'بیشتر'),
          ],
        ),
      ),
    );
  }
}

class Logo extends StatelessWidget {
  final double width;
  const Logo({super.key, this.width = 130});
  @override Widget build(BuildContext context) => Image.asset('assets/roshan_mihan_logo.jpg', width: width, fit: BoxFit.contain);
}

class HomePage extends StatelessWidget {
  final void Function(int) onNavigate;
  const HomePage({super.key, required this.onNavigate});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.fromLTRB(18, 14, 18, 30),
    children: [
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        const Logo(width: 110),
        IconButton(onPressed: () => openWhatsApp(message: 'سلام، درباره محصولات روشن میهن سوال دارم.'), icon: const Icon(Icons.chat_outlined, color: red)),
      ]),
      const SizedBox(height: 12),
      Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(color: black, borderRadius: BorderRadius.circular(24)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('روشن میهن', style: TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          const Text('ماربل شیت و فومیزه PVC برای فضاهای مدرن و ماندگار.', style: TextStyle(color: Colors.white70, fontSize: 15, height: 1.6)),
          const SizedBox(height: 18),
          Wrap(spacing: 10, runSpacing: 10, children: [
            ElevatedButton(onPressed: () => onNavigate(1), style: ElevatedButton.styleFrom(backgroundColor: red, foregroundColor: Colors.white), child: const Text('مشاهده محصولات')),
            OutlinedButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const OrderPage())), style: OutlinedButton.styleFrom(foregroundColor: Colors.white, side: const BorderSide(color: Colors.white54)), child: const Text('ثبت سفارش')),
          ]),
        ]),
      ),
      const SizedBox(height: 22),
      const SectionTitle('محصولات منتخب'),
      ...products.take(3).map((p) => ProductCard(product: p, onWhatsApp: () => openWhatsApp(message: 'سلام، قیمت ${p.name} را می‌خواهم.'))),
      const SizedBox(height: 12),
      const SectionTitle('ویژگی‌های محصولات'),
      const FeatureGrid(),
      const SizedBox(height: 22),
      const SectionTitle('خدمات سریع'),
      Row(children: [
        Expanded(child: QuickAction(icon: Icons.calculate, title: 'محاسبه متراژ', onTap: () => onNavigate(3))),
        const SizedBox(width: 10),
        Expanded(child: QuickAction(icon: Icons.chat, title: 'واتساپ', onTap: () => openWhatsApp())),
        const SizedBox(width: 10),
        Expanded(child: QuickAction(icon: Icons.directions, title: 'مسیریابی', onTap: openStoreMap)),
      ]),
      const SizedBox(height: 22),
      const SectionTitle('اطلاعات تماس'),
      Card(child: ListTile(
        leading: const CircleAvatar(backgroundColor: Color(0xFFFFE5E7), child: Icon(Icons.location_on, color: red)),
        title: const Text('کوتۀ سنگی، بین سرک ۴ و ۵، سیلو مارکیت'),
        subtitle: const Text('قاری محمد امین'),
        trailing: IconButton(onPressed: openStoreMap, icon: const Icon(Icons.directions, color: red)),
      )),
    ],
  );
}

class SectionTitle extends StatelessWidget {
  final String text;
  const SectionTitle(this.text, {super.key});
  @override Widget build(BuildContext context) => Padding(padding: const EdgeInsets.only(bottom: 10), child: Text(text, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w800)));
}

class FeatureGrid extends StatelessWidget {
  const FeatureGrid({super.key});
  @override Widget build(BuildContext context) => Wrap(spacing: 10, runSpacing: 10, children: const [
    Feature(icon: Icons.water_drop_outlined, text: 'ضد نم و آب'),
    Feature(icon: Icons.cleaning_services_outlined, text: 'قابل شستشو'),
    Feature(icon: Icons.speed_outlined, text: 'نصب سریع'),
    Feature(icon: Icons.layers_outlined, text: 'بیش از ۲۰ طرح'),
  ]);
}
class Feature extends StatelessWidget {
  final IconData icon; final String text;
  const Feature({super.key, required this.icon, required this.text});
  @override Widget build(BuildContext context) => Container(
    width: (MediaQuery.of(context).size.width - 56) / 2, padding: const EdgeInsets.all(15),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
    child: Row(children: [Icon(icon, color: red), const SizedBox(width: 8), Expanded(child: Text(text, style: const TextStyle(fontWeight: FontWeight.w600)))]),
  );
}
class QuickAction extends StatelessWidget {
  final IconData icon; final String title; final VoidCallback onTap;
  const QuickAction({super.key, required this.icon, required this.title, required this.onTap});
  @override Widget build(BuildContext context) => InkWell(
    onTap: onTap, borderRadius: BorderRadius.circular(16),
    child: Container(padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 8), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
      child: Column(children: [Icon(icon, color: red), const SizedBox(height: 8), Text(title, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12))]),
  );
}

class ProductsPage extends StatefulWidget {
  final Set<String> favorites; final void Function(Product) onFav;
  const ProductsPage({super.key, required this.favorites, required this.onFav});
  @override State<ProductsPage> createState() => _ProductsPageState();
}
class _ProductsPageState extends State<ProductsPage> {
  String category = 'همه', query = '';
  @override Widget build(BuildContext context) {
    final filtered = products.where((p) => (category == 'همه' || p.category == category) && (p.name.contains(query) || p.category.contains(query))).toList();
    return Column(children: [
      const Padding(padding: EdgeInsets.fromLTRB(18, 18, 18, 6), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('محصولات', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)), Logo(width: 80)])),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8), child: TextField(onChanged: (v) => setState(() => query = v), decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'جستجوی محصول...'))),
      SingleChildScrollView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 18), child: Row(children: ['همه', 'ماربل شیت', 'فومیزه PVC'].map((c) => Padding(padding: const EdgeInsets.only(left: 8), child: ChoiceChip(label: Text(c), selected: category == c, selectedColor: const Color(0xFFFFD9DC), onSelected: (_) => setState(() => category = c)))).toList())),
      const SizedBox(height: 10),
      Expanded(child: ListView.builder(padding: const EdgeInsets.symmetric(horizontal: 18), itemCount: filtered.length, itemBuilder: (_, i) => ProductCard(product: filtered[i], favorite: widget.favorites.contains(filtered[i].name), onFav: () => widget.onFav(filtered[i]), onWhatsApp: () => openWhatsApp(message: 'سلام، قیمت ${filtered[i].name} را می‌خواهم.')))),
    ]);
  }
}

class ProductCard extends StatelessWidget {
  final Product product; final bool favorite; final VoidCallback? onFav; final VoidCallback onWhatsApp;
  const ProductCard({super.key, required this.product, this.favorite = false, this.onFav, required this.onWhatsApp});
  @override Widget build(BuildContext context) => Card(
    margin: const EdgeInsets.only(bottom: 12),
    child: Padding(padding: const EdgeInsets.all(14), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Container(width: 78, height: 78, decoration: BoxDecoration(color: const Color(0xFFF0F0F0), borderRadius: BorderRadius.circular(14)), child: const Icon(Icons.image_outlined, size: 34, color: Colors.black38)),
      const SizedBox(width: 14),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(product.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
        const SizedBox(height: 5),
        Text(product.specs, style: const TextStyle(color: Colors.black54, height: 1.5, fontSize: 12)),
        const SizedBox(height: 9),
        Row(children: [
          Expanded(child: OutlinedButton.icon(onPressed: onWhatsApp, icon: const Icon(Icons.chat, size: 17), label: const Text('دریافت قیمت'))),
          if (onFav != null) IconButton(onPressed: onFav, icon: Icon(favorite ? Icons.favorite : Icons.favorite_border, color: red)),
        ]),
      ])),
    ]),
  );
}

class GalleryPage extends StatelessWidget {
  const GalleryPage({super.key});
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('گالری پروژه‌ها', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
    const SizedBox(height: 8),
    const Text('گالری در نسخه اولیه خالی است و بعداً از پنل مدیریت قابل تکمیل خواهد بود.', style: TextStyle(color: Colors.black54)),
    const SizedBox(height: 18),
    Container(height: 250, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22)), child: const Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Icon(Icons.photo_library_outlined, size: 62, color: Colors.black26),
      SizedBox(height: 12), Text('هنوز تصویری اضافه نشده است', style: TextStyle(fontWeight: FontWeight.w700)),
    ])),
  ]);
}

class CalculatorPage extends StatefulWidget {
  const CalculatorPage({super.key});
  @override State<CalculatorPage> createState() => _CalculatorPageState();
}
class _CalculatorPageState extends State<CalculatorPage> {
  final w = TextEditingController(), h = TextEditingController();
  double area = 0, sheets = 0;
  void calc() {
    final width = double.tryParse(w.text.replaceAll(',', '.')) ?? 0;
    final height = double.tryParse(h.text.replaceAll(',', '.')) ?? 0;
    final a = width * height;
    setState(() { area = a; sheets = a <= 0 ? 0 : (a / (1.2 * 2.8)).ceilToDouble(); });
  }
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('محاسبه متراژ', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
    const SizedBox(height: 8), const Text('ابعاد دیوار را بر حسب متر وارد کنید.', style: TextStyle(color: Colors.black54)),
    const SizedBox(height: 18),
    TextField(controller: w, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'عرض دیوار (متر)', prefixIcon: Icon(Icons.straighten))),
    const SizedBox(height: 12),
    TextField(controller: h, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'ارتفاع دیوار (متر)', prefixIcon: Icon(Icons.height))),
    const SizedBox(height: 14),
    SizedBox(height: 52, child: ElevatedButton(onPressed: calc, style: ElevatedButton.styleFrom(backgroundColor: red, foregroundColor: Colors.white), child: const Text('محاسبه'))),
    if (area > 0) ...[
      const SizedBox(height: 18),
      Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(children: [
        const Text('نتیجه', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
        const SizedBox(height: 12),
        Text('${area.toStringAsFixed(2)} متر مربع', style: const TextStyle(fontSize: 27, fontWeight: FontWeight.w900, color: red)),
        Text('تعداد تقریبی ورق: ${sheets.toInt()}', style: const TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 14),
        SizedBox(width: double.infinity, child: OutlinedButton.icon(
          onPressed: () => openWhatsApp(message: 'سلام، محاسبه متراژ من:\nمساحت: ${area.toStringAsFixed(2)} متر مربع\nتعداد تقریبی ورق: ${sheets.toInt()}\nلطفاً قیمت را اعلام کنید.'),
          icon: const Icon(Icons.chat), label: const Text('ارسال نتیجه در واتساپ'),
        )),
      ])),
    ],
  ]);
}

class OrderPage extends StatefulWidget {
  const OrderPage({super.key});
  @override State<OrderPage> createState() => _OrderPageState();
}
class _OrderPageState extends State<OrderPage> {
  final name = TextEditingController(), phone = TextEditingController(), notes = TextEditingController();
  String? product, address = '';
  Position? pos; bool loading = false;

  Future<void> locate() async {
    setState(() => loading = true);
    try {
      if (!await Geolocator.isLocationServiceEnabled()) throw Exception('سرویس موقعیت مکانی گوشی خاموش است.');
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) throw Exception('اجازه موقعیت مکانی داده نشد.');
      final p = await Geolocator.getCurrentPosition(locationSettings: const LocationSettings(accuracy: LocationAccuracy.high));
      String addr = 'موقعیت ثبت شد';
      try {
        final list = await placemarkFromCoordinates(p.latitude, p.longitude);
        if (list.isNotEmpty) {
          final x = list.first;
          addr = [x.street, x.subLocality, x.locality, x.administrativeArea].where((e) => e != null && e!.trim().isNotEmpty).join('، ');
        }
      } catch (_) {}
      setState(() { pos = p; address = addr; });
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))));
    } finally { if (mounted) setState(() => loading = false); }
  }

  Future<void> submit() async {
    if (name.text.trim().isEmpty || phone.text.trim().isEmpty || product == null || pos == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('نام، شماره تماس، محصول و موقعیت مکانی اجباری است.'))); return;
    }
    final orderNo = 'RM-${DateTime.now().millisecondsSinceEpoch.toString().substring(6)}';
    final msg = 'سلام روشن میهن، سفارش جدید:\n'
        'شماره سفارش: $orderNo\nنام: ${name.text}\nشماره تماس: ${phone.text}\nمحصول: $product\n'
        'آدرس خودکار: $address\nمختصات: ${pos!.latitude}, ${pos!.longitude}\nتوضیحات: ${notes.text}';
    await openWhatsApp(message: msg);
    if (mounted) await showDialog(context: context, builder: (_) => AlertDialog(
      title: const Text('سفارش آماده ارسال است'),
      content: Text('شماره سفارش شما:\n$orderNo\n\nپیام سفارش در واتساپ آماده شده است.'),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('باشه'))],
    ));
  }

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('ثبت سفارش')),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      const Text('اطلاعات مشتری', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800)),
      const SizedBox(height: 12),
      TextField(controller: name, decoration: const InputDecoration(labelText: 'نام و نام خانوادگی')),
      const SizedBox(height: 10),
      TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'شماره تماس')),
      const SizedBox(height: 10),
      DropdownButtonFormField<String>(value: product, decoration: const InputDecoration(labelText: 'انتخاب محصول'), items: products.map((p) => DropdownMenuItem(value: p.name, child: Text(p.name))).toList(), onChanged: (v) => setState(() => product = v)),
      const SizedBox(height: 22),
      const Text('آدرس و موقعیت', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800)),
      const SizedBox(height: 8),
      const Text('برای کاهش خطای آدرس، ثبت موقعیت مکانی اجباری است.', style: TextStyle(color: Colors.black54)),
      const SizedBox(height: 10),
      SizedBox(height: 52, child: ElevatedButton.icon(
        onPressed: loading ? null : locate,
        icon: loading ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.my_location),
        label: Text(pos == null ? 'ثبت موقعیت مکانی من' : 'موقعیت ثبت شد'),
      )),
      if (pos != null) ...[
        const SizedBox(height: 12),
        Container(height: 230, clipBehavior: Clip.antiAlias, decoration: BoxDecoration(borderRadius: BorderRadius.circular(18)),
          child: FlutterMap(options: MapOptions(initialCenter: LatLng(pos!.latitude, pos!.longitude), initialZoom: 16), children: [
            TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'com.roshanmihan.app'),
            MarkerLayer(markers: [Marker(point: LatLng(pos!.latitude, pos!.longitude), width: 50, height: 50, child: const Icon(Icons.location_pin, color: red, size: 46))]),
          ]),
        ),
        const SizedBox(height: 10),
        Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('آدرس خودکار', style: TextStyle(fontWeight: FontWeight.w800)), const SizedBox(height: 5), Text(address!),
          const SizedBox(height: 10), Text('مختصات: ${pos!.latitude.toStringAsFixed(6)}, ${pos!.longitude.toStringAsFixed(6)}', style: const TextStyle(fontSize: 12, color: Colors.black54)),
        ]))),
      ],
      const SizedBox(height: 12),
      TextField(controller: notes, maxLines: 3, decoration: const InputDecoration(labelText: 'چیزی اضافه کنید', hintText: 'مثلاً: کوچه دوم، خانه آبی، کنار مسجد...')),
      const SizedBox(height: 18),
      SizedBox(height: 54, child: ElevatedButton(onPressed: submit, style: ElevatedButton.styleFrom(backgroundColor: red, foregroundColor: Colors.white), child: const Text('تأیید موقعیت و ارسال سفارش'))),
    ]),
  );
}

class MorePage extends StatelessWidget {
  const MorePage({super.key});
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const Logo(width: 145),
    const SizedBox(height: 12),
    const Text('روشن میهن', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
    const Text('فروشات ماربل شیت و فومیزه PVC', style: TextStyle(color: Colors.black54)),
    const SizedBox(height: 18),
    Card(child: Column(children: [
      ListTile(leading: const Icon(Icons.receipt_long, color: red), title: const Text('ثبت سفارش'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const OrderPage()))),
      ListTile(leading: const Icon(Icons.local_shipping_outlined, color: red), title: const Text('پیگیری سفارش'), onTap: () => showTracking(context)),
      ListTile(leading: const Icon(Icons.chat_outlined, color: red), title: const Text('واتساپ'), onTap: () => openWhatsApp()),
      ListTile(leading: const Icon(Icons.phone_outlined, color: red), title: const Text('تماس با شرکت'), onTap: makeCall),
      ListTile(leading: const Icon(Icons.map_outlined, color: red), title: const Text('مسیریابی فروشگاه'), onTap: openStoreMap),
      ListTile(leading: const Icon(Icons.info_outline, color: red), title: const Text('درباره ما'), onTap: () => showAbout(context)),
    ])),
    const SizedBox(height: 18),
    const Text('نسخه اولیه 1.0.0', textAlign: TextAlign.center, style: TextStyle(color: Colors.black38)),
  ]);
}

void showTracking(BuildContext context) {
  final c = TextEditingController();
  showDialog(context: context, builder: (_) => AlertDialog(
    title: const Text('پیگیری سفارش'),
    content: TextField(controller: c, decoration: const InputDecoration(labelText: 'شماره سفارش', hintText: 'مثلاً RM-123456')),
    actions: [
      TextButton(onPressed: () => Navigator.pop(context), child: const Text('انصراف')),
      ElevatedButton(onPressed: () {
        Navigator.pop(context);
        showDialog(context: context, builder: (_) => AlertDialog(
          title: Text('سفارش ${c.text.isEmpty ? '---' : c.text}'),
          content: const Column(mainAxisSize: MainAxisSize.min, children: [
            ListTile(leading: Icon(Icons.check_circle, color: red), title: Text('ثبت شد')),
            ListTile(leading: Icon(Icons.radio_button_checked, color: red), title: Text('تأیید شد')),
            ListTile(leading: Icon(Icons.radio_button_unchecked), title: Text('آماده‌سازی')),
            ListTile(leading: Icon(Icons.radio_button_unchecked), title: Text('ارسال شد')),
            ListTile(leading: Icon(Icons.radio_button_unchecked), title: Text('تحویل شد')),
          ]),
          actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('باشه'))],
        ));
      }, child: const Text('پیگیری')),
    ],
  ));
}

void showAbout(BuildContext context) => showDialog(context: context, builder: (_) => AlertDialog(
  title: const Text('درباره روشن میهن'),
  content: const Text('روشن میهن\n\nفروشات ماربل شیت و فومیزه PVC\n\nکوتۀ سنگی، بین سرک ۴ و ۵، سیلو مارکیت، قاری محمد امین'),
  actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('بستن'))],
));
